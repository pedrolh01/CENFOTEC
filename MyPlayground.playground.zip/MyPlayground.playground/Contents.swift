import Foundation



struct Dog {
    var name: String
    var age: Int
}


let dogs = [Dog(name: "perro 1", age: 20), Dog(name: "perro 2", age: 3), Dog(name: "perro 3", age: 5), Dog(name: "perro 4", age: 1)]




let dogOrdered = dogs.sorted(by: {$0.age > $1.age}) // esto hace un ordenar

let dogFiltered = dogs.filter({$0.age >= 5}) //esto hace un query en el array


let dogNames = dogs.map({$0.name}) // convertir un array a otro tipo






print(dogFiltered)
