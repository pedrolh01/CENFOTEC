//
//  News.swift
//  Clase#4
//
//  Created by Cesar Brenes on 3/14/20.
//  Copyright © 2020 VeuxLabs. All rights reserved.
//

import Foundation

struct News {
    var date = Date()
    var title: String
    var descriptionNews: String
}
