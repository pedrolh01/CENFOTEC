//
//  Person.swift
//  Clase#2
//
//  Created by Cesar Brenes on 2/29/20.
//  Copyright © 2020 VeuxLabs. All rights reserved.
//

import Foundation

//
//class Person: NSObject {
//    var name: String
//    var lastName: String
//
//    init(name: String, lastName:String) {
//        self.name = name
//        self.lastName = lastName
//    }
//}

struct Person {
    var name: String
    var lastName: String
    
}
